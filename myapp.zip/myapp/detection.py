import re

# Simple keyword lists (extend these lists for better detection)
PHISHING_KEYWORDS = [
    'account', 'verify', 'password', 'login', 'click here', 'urgent', 'limited time',
    'security alert', 'bank', 'update', 'suspend', 'confirm', 'prize', 'won'
]

CYBERBULLYING_KEYWORDS = {
    'harassment': ['annoy', 'bother', 'pester', 'harass', 'persecute', 'torment'],
    'threat': ['kill', 'hurt', 'attack', 'destroy', 'harm', 'threaten'],
    'insult': ['stupid', 'idiot', 'moron', 'dumb', 'ugly', 'fat', 'worthless']
}

def detect_phishing(text):
    text_lower = text.lower()
    for keyword in PHISHING_KEYWORDS:
        if keyword in text_lower:
            return True
    return False

def detect_cyberbullying(text):
    text_lower = text.lower()
    for category, keywords in CYBERBULLYING_KEYWORDS.items():
        for keyword in keywords:
            if keyword in text_lower:
                return True
    return False

def classify_bullying_type(text):
    text_lower = text.lower()
    for category, keywords in CYBERBULLYING_KEYWORDS.items():
        for keyword in keywords:
            if keyword in text_lower:
                return category
    return "None"
